#!/bin/bash
curl --data-binary @job-server-tests_2.10-0.1.0-ALGORITHMS.jar localhost:8090/jars/algorithms

