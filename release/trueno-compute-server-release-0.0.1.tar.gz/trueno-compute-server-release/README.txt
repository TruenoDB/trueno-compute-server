Running Spark-Job-Server:
./server_start.sh --jars spark-cassandra-connector-1.6.0-M2-s_2.10.jar  &

Uploading algorithms:
curl --data-binary @job-server-tests_2.10-0.1.0-ALGORITHMS.jar localhost:8090/jars/algorithms


